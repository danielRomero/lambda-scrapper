var gulp = require('gulp');
var zip = require('gulp-zip');

gulp.task('zip', [], function() {
  var targetDir = 'dist/';
  var packagename = require('./package.json').name;
  var filename = packagename + '.zip';

  return gulp.src([
                  '**',
                  '!dist', '!dist/**'
                  ])
  .pipe(zip(filename))
  .pipe(gulp.dest(targetDir));
});
