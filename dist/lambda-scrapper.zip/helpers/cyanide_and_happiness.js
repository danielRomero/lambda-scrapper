const request = require('axios');
const {extractListingsFromHTML} = require('./helpers');

module.exports.test2 = (event, context, callback) => {
  request('http://explosm.net/')
    .then(({data}) => {
      const jobs = extractListingsFromHTML(data);
      callback(null, {jobs});
    })
    .catch(callback);
};
