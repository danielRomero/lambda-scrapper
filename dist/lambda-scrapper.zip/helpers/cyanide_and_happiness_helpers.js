const cheerio = require('cheerio');

function extractListingsFromHTML (html) {
  // const $ = cheerio.load(html);
  // const image = $('html.js.flexbox.flexboxlegacy.canvas.canvastext.webgl.no-touch.geolocation.postmessage.no-websqldatabase.indexeddb.hashchange.history.draganddrop.websockets.rgba.hsla.multiplebgs.backgroundsize.borderimage.borderradius.boxshadow.textshadow.opacity.cssanimations.csscolumns.cssgradients.no-cssreflections.csstransforms.csstransforms3d.csstransitions.fontface.generatedcontent.video.audio.localstorage.sessionstorage.webworkers.applicationcache.svg.inlinesvg.smil.svgclippaths body div.off-canvas-wrap div.inner-wrap div.row div.medium-12.large-8.columns div#comic-container div.row div.small-12.medium-12.large-12.columns img#main-comic');

  // const iamge_url = image

  // return iamge_url;
  return "llamada a module con " + html;
}

module.exports = {
  extractListingsFromHTML
};
