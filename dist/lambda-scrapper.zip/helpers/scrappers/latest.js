const cheerio = require('cheerio');
const {getHTML} = require('./get_html');
const latest_url = "http://explosm.net/";

function extractLatestComic (callback) {
  console.log("extracting latest comic");
  getHTML(latest_url).then(function (html) {
    console.log("html loaded");
    var $ = cheerio.load(html);
    var image = $("#featured-comic");
    var image_url = image.attr('src');
    callback(null, image_url);
  })
  .catch(function (error) {
    callback(error);
  });
}

module.exports = {
  extractLatestComic
};
