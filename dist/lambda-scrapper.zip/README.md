Test lambda in local dev env
nodejs test.js

Create Zip lambda
zip --exclude \*dist\* -r dist/${PWD##*/}.zip .
