"use strict";

const cheerio = require('cheerio');
const {getHTML} = require('./get_html');

function getImageComic (url, css_img_selector) {

  console.log("extracting latest comic");
  return getHTML(url).then(function (html) {
    console.log("html loaded");

    var $ = cheerio.load(html);
    var image_dom = $(css_img_selector);
    const image_url = image_dom.attr('src');

    var parsed_image_url = parse_image_url(image_url);

    return parsed_image_url;
  })
  .catch(function (error) {
    throw error;
  });
}

function parse_image_url(image_url){
  console.log(typeof image_url);
  if(image_url.startsWith("//")){
    return image_url.slice(2); // remove first two chars of string
  }else{
    return image_url
  }
}

module.exports = {
  getImageComic
};
