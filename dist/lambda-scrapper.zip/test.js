const {main} = require('./main');

const event = null;
const context = null;

main(event, context, function(result){
  console.log(result);
});
